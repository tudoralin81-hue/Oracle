package ro.alintudor.oracle.nativeui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.animation.ObjectAnimator
import android.view.animation.LinearInterpolator
import android.widget.Toast
import ro.alintudor.oracle.core.OracleGrowthEngine
import ro.alintudor.oracle.core.OracleGrowthJournalStore
import ro.alintudor.oracle.core.OracleGrowthPhase
import ro.alintudor.oracle.core.OracleGrowthProgress
import ro.alintudor.oracle.core.OracleGrowthRecommendation
import ro.alintudor.oracle.core.OracleNews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Growth module. Visual structure follows the approved mobile Growth mockup,
 * while values remain the persisted Oracle snapshot and are never recalculated here.
 */
class OracleGrowthModule(private val host: OracleNativeModule) {
    private val bg = Color.rgb(6, 10, 20)
    private val panel = Color.rgb(7, 14, 28)
    private val border = Color.rgb(49, 82, 125)
    private val muted = Color.rgb(165, 174, 195)
    private val cyan = Color.rgb(75, 225, 255)
    private val orange = Color.rgb(255, 160, 25)
    private val green = Color.rgb(105, 245, 35)
    private val red = Color.rgb(255, 80, 90)
    private val white = Color.WHITE
    private val journalStore = OracleGrowthJournalStore(host.root.context)

    fun render(items: List<OracleGrowthRecommendation>, fallbackNews: List<OracleNews> = emptyList()) {
        host.content.removeAllViews()
        if (items.isEmpty()) {
            addLoadingState()
            return
        }

        // GrowthBanner from the shared module shell is the single Growth hero.
        // Do not add a second Growth banner here.
        journalStore.record(items)
        addSummary(items)

        val ordered = listOf("SHORT", "MEDIUM", "LONG").mapNotNull { horizon ->
            items.firstOrNull { it.horizon.equals(horizon, true) }
        }
        if (ordered.isNotEmpty()) addRecommendations(ordered, fallbackNews)
        addNews(ordered, fallbackNews)
        addHistory(journalStore.load())
        addBuildFooter()
    }

    // B540 — investor quotes rotated in the loader every 15s (Requirement #7).
    // Local strings only; no network request is made to show them.
    private val loaderQuotes = listOf(
        "\"Price is what you pay; value is what you get.\"\n— Benjamin Graham",
        "\"Rule No. 1: Never lose money. Rule No. 2: Never forget Rule No. 1.\"\n— Warren Buffett",
        "\"The most important quality for an investor is temperament, not intellect.\"\n— Warren Buffett",
        "\"It's only when the tide goes out that you learn who's been swimming naked.\"\n— Warren Buffett",
        "\"In the short run, the market is a voting machine, but in the long run it is a weighing machine.\"\n— Benjamin Graham",
        "\"The intelligent investor is a realist who sells to optimists and buys from pessimists.\"\n— Benjamin Graham",
        "\"Invert, always invert.\"\n— Charlie Munger",
        "\"Behind every stock is a company. Find out what it's doing.\"\n— Peter Lynch",
        "\"The four most dangerous words in investing are: this time it's different.\"\n— Sir John Templeton"
    )

    /**
     * B540 loading state (Requirement #6/#7/#11).
     *
     * Shows real progress ("DATE ÎNCĂRCATE: X / 500", updated in steps of 50),
     * an ETA computed from actual throughput, and a rotating investor quote.
     * If [OracleGrowthEngine] has already finished with zero OHLCV received,
     * this renders an explicit error state instead — it never spins forever.
     */
    private fun addLoadingState() {
        val initial = OracleGrowthEngine.growthProgress()
        if (initial.phase == OracleGrowthPhase.NO_DATA) {
            addNoDataState(initial)
            return
        }

        val card = card(18)
        card.gravity = Gravity.CENTER
        val spinner = ImageView(host.root.context).apply {
            setImageResource(ro.alintudor.oracle.R.drawable.ic_oracle)
            contentDescription = "Oracle se calculează"
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            val rotation = ObjectAnimator.ofFloat(this, View.ROTATION, 0f, 360f).apply {
                duration = 1100L
                repeatCount = ObjectAnimator.INFINITE
                interpolator = LinearInterpolator()
            }
            rotation.start()
        }
        card.addView(spinner, LinearLayout.LayoutParams(host.dp(54), host.dp(54)).apply { gravity = Gravity.CENTER })
        card.addView(text("GROWTH", 17f, Typeface.DEFAULT_BOLD, green, 0, 10).apply { gravity = Gravity.CENTER })
        card.addView(text("Se calculează recomandările…", 13f, Typeface.DEFAULT, muted, 0, 5).apply { gravity = Gravity.CENTER })
        val progressLabel = text("DATE ÎNCĂRCATE: 0 / ${initial.total}", 12f, Typeface.DEFAULT_BOLD, cyan, 0, 10).apply { gravity = Gravity.CENTER }
        card.addView(progressLabel)
        val progressBar = ProgressBar(host.root.context, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = initial.total.coerceAtLeast(1); progress = 0; isIndeterminate = false
        }
        card.addView(progressBar, LinearLayout.LayoutParams(-1, host.dp(9)).apply { setMargins(host.dp(10), host.dp(6), host.dp(10), host.dp(3)) })
        val etaLabel = text("Timp estimat: se calculează…", 10f, Typeface.DEFAULT_BOLD, green, 0, 5).apply { gravity = Gravity.CENTER }
        card.addView(etaLabel)
        val quoteLabel = text(loaderQuotes.first(), 10f, Typeface.DEFAULT, white, 0, 9).apply { gravity = Gravity.CENTER; setLineSpacing(0f, 1.1f) }
        card.addView(quoteLabel)
        card.addView(text("Analiza se execută în fundal. Valorile apar numai după finalizarea calculului curent.", 9f, Typeface.DEFAULT, muted, 0, 9).apply { gravity = Gravity.CENTER })
        card.addView(text("Maxim țintă: 20 secunde", 9f, Typeface.DEFAULT_BOLD, muted, 0, 6).apply { gravity = Gravity.CENTER })
        host.content.addView(card, LinearLayout.LayoutParams(-1, host.dp(275)).apply { setMargins(0, 0, 0, host.dp(10)) })
        addBuildFooter()

        val handler = Handler(Looper.getMainLooper())
        var quoteIndex = 0
        val quoteRunnable = object : Runnable {
            override fun run() {
                quoteIndex = (quoteIndex + 1) % loaderQuotes.size
                quoteLabel.text = loaderQuotes[quoteIndex]
                handler.postDelayed(this, 15_000L)
            }
        }
        handler.postDelayed(quoteRunnable, 15_000L)

        val progressRunnable = object : Runnable {
            override fun run() {
                val p = OracleGrowthEngine.growthProgress()
                if (p.phase == OracleGrowthPhase.NO_DATA) {
                    handler.removeCallbacksAndMessages(null)
                    addNoDataState(p)
                    return
                }
                val total = p.total.coerceAtLeast(1)
                val loaded = p.loaded.coerceIn(0, total)
                // Requirement #6: the visible counter steps in increments of 50;
                // the engine tracks the exact count internally.
                val shown = if (loaded >= total) total else (loaded / 50) * 50
                progressBar.max = total
                progressBar.progress = shown
                progressLabel.text = "DATE ÎNCĂRCATE: $shown / $total"
                if (p.startedAtNanos > 0L) {
                    val elapsed = (System.nanoTime() - p.startedAtNanos).coerceAtLeast(1L) / 1_000_000_000.0
                    etaLabel.text = if (p.phase == OracleGrowthPhase.RUNNING) {
                        if (shown > 0) {
                            val eta = (elapsed * (total - shown) / shown).coerceAtLeast(0.0)
                            "Timp estimat: ~${formatEta(eta)}"
                        } else "Timp estimat: se calculează…"
                    } else {
                        "Analiza datelor: finalizată în ${String.format(Locale.US, "%.1f", elapsed)} s"
                    }
                }
                if (p.phase == OracleGrowthPhase.RUNNING) handler.postDelayed(this, 500L)
            }
        }
        handler.post(progressRunnable)
    }

    /** Requirement #6/#11: explicit, non-infinite error state when 0 OHLCV was received. */
    private fun addNoDataState(progress: OracleGrowthProgress) {
        host.content.removeAllViews()
        val card = card(18)
        card.gravity = Gravity.CENTER
        card.background = rounded(bg, red, 1, 16)
        card.addView(text("⚠", 28f, Typeface.DEFAULT_BOLD, red, 0, 0).apply { gravity = Gravity.CENTER })
        card.addView(text("GROWTH", 17f, Typeface.DEFAULT_BOLD, green, 0, 10).apply { gravity = Gravity.CENTER })
        card.addView(text("Sursa de date OHLCV nu a răspuns.", 13f, Typeface.DEFAULT_BOLD, red, 0, 6).apply { gravity = Gravity.CENTER })
        card.addView(text("Recomandările Growth nu au putut fi calculate (${progress.loaded} / ${progress.total} simboluri primite).", 11f, Typeface.DEFAULT, muted, 0, 6).apply { gravity = Gravity.CENTER })
        card.addView(text("Apasă ↻ (sus dreapta) pentru a reîncerca.", 11f, Typeface.DEFAULT_BOLD, cyan, 0, 6).apply { gravity = Gravity.CENTER })
        host.content.addView(card, LinearLayout.LayoutParams(-1, host.dp(200)).apply { setMargins(0, 0, 0, host.dp(10)) })
        addBuildFooter()
    }

    private fun formatEta(seconds: Double): String {
        val rounded = kotlin.math.ceil(seconds).toInt().coerceAtLeast(0)
        return if (rounded < 60) "$rounded sec" else "${rounded / 60} min ${rounded % 60} sec"
    }

    private fun addSummary(items: List<OracleGrowthRecommendation>) {
        val card = card(14)
        card.addView(text("RECOMANDĂRILE DE CREȘTERE", 18f, Typeface.DEFAULT_BOLD, green, 0, 0))
        card.addView(text("Oracle Growth • snapshot zilnic 16:00", 13f, Typeface.DEFAULT, muted, 0, 5))
        val line = LinearLayout(host.root.context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, host.dp(12), 0, 0)
        }
        line.addView(metric("ORIZONTURI", items.map { it.horizon }.distinct().size.toString(), cyan), LinearLayout.LayoutParams(0, -2, 1f))
        line.addView(metric("RECOMANDĂRI", items.size.toString(), orange), LinearLayout.LayoutParams(0, -2, 1f))
        line.addView(metric("ANCHOR", formatT0(items.first().referenceTimestamp), white), LinearLayout.LayoutParams(0, -2, 1.55f))
        card.addView(line)
        host.content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, host.dp(10)) })
    }

    private fun addRecommendations(items: List<OracleGrowthRecommendation>, news: List<OracleNews>) {
        val section = TextView(host.root.context).apply {
            text = "SUMAR RECOMANDĂRI ACTIVE"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(green)
            setPadding(host.dp(4), host.dp(3), host.dp(4), host.dp(7))
        }
        host.content.addView(section)
        items.forEach { addRecommendationCard(it, news) }
    }

    private fun addRecommendationCard(item: OracleGrowthRecommendation, news: List<OracleNews>) {
        val accent = when (item.horizon.uppercase(Locale.US)) { "SHORT" -> cyan; "MEDIUM" -> orange; else -> green }
        val card = card(12).apply { background = rounded(bg, accent, 1, 15) }
        val top = LinearLayout(host.root.context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(host.root.context).apply { orientation = LinearLayout.VERTICAL }
        left.addView(text(horizonLabel(item.horizon), 13f, Typeface.DEFAULT_BOLD, accent, 0, 0))
        left.addView(text(horizonRange(item.horizon), 11f, Typeface.DEFAULT, muted, 0, 3))
        top.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(text(formatT0(item.referenceTimestamp), 10f, Typeface.DEFAULT, muted, 0, 0))
        card.addView(top)

        val identity = LinearLayout(host.root.context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, host.dp(10), 0, host.dp(8)) }
        val ticker = text(item.ticker, 30f, Typeface.DEFAULT_BOLD, white, 0, 0)
        identity.addView(ticker, LinearLayout.LayoutParams(host.dp(120), -2))
        val company = LinearLayout(host.root.context).apply { orientation = LinearLayout.VERTICAL }
        company.addView(text(item.company, 15f, Typeface.DEFAULT_BOLD, white, 0, 0))
        company.addView(text(item.sector, 11f, Typeface.DEFAULT_BOLD, Color.rgb(150, 170, 205), 0, 4))
        identity.addView(company, LinearLayout.LayoutParams(0, -2, 1f))
        identity.addView(text("›", 28f, Typeface.DEFAULT, accent, 0, 0))
        card.addView(identity)
        card.addView(divider())

        val metrics = LinearLayout(host.root.context).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, host.dp(7), 0, host.dp(4)) }
        metrics.addView(metric("SCOR", "${item.score}/100", cyan), LinearLayout.LayoutParams(0, -2, 1f))
        metrics.addView(metric("SEMNAL", compactSignal(item.signal), orange), LinearLayout.LayoutParams(0, -2, 1.15f))
        metrics.addView(metric("RISC", item.risk, riskColor(item.risk)), LinearLayout.LayoutParams(0, -2, 1f))
        metrics.addView(metric("ALOCARE", "${format(item.allocationMax)}%", orange), LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(metrics)

        val lower = LinearLayout(host.root.context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, host.dp(5), 0, host.dp(4)) }
        val forecast = LinearLayout(host.root.context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        forecast.addView(text("Potențial estimat", 10f, Typeface.DEFAULT, muted, 0, 0))
        forecast.addView(text(signedPct(item.forecastPct), 22f, Typeface.DEFAULT_BOLD, green, 0, 2))
        lower.addView(forecast, LinearLayout.LayoutParams(0, -2, 1.15f))
        val momentum = LinearLayout(host.root.context).apply { orientation = LinearLayout.VERTICAL }
        momentum.addView(text("Momentum", 10f, Typeface.DEFAULT, muted, 0, 0))
        momentum.addView(text("5D: ${signedPct(item.momentum5D)}", 11f, Typeface.DEFAULT_BOLD, cyan, 0, 2))
        momentum.addView(text("20D: ${signedPct(item.momentum20D)}", 11f, Typeface.DEFAULT_BOLD, cyan, 0, 2))
        lower.addView(momentum, LinearLayout.LayoutParams(0, -2, 1.1f))
        lower.addView(SparklineView(host.root.context, accent), LinearLayout.LayoutParams(host.dp(112), host.dp(52)))
        card.addView(lower)
        addCompactWeights(card, item.weights)

        val linked = news.firstOrNull { it.ticker.equals(item.ticker, true) }
        val newsTitle = if (item.newsTitle.isNotBlank()) item.newsTitle else linked?.title.orEmpty()
        val source = if (item.newsSource.isNotBlank()) item.newsSource else linked?.source.orEmpty()
        if (newsTitle.isNotBlank()) {
            card.addView(text("▣  ${if (source.isBlank()) "NEWS" else source}", 10f, Typeface.DEFAULT_BOLD, cyan, 0, 5))
            card.addView(text(newsTitle, 11f, Typeface.DEFAULT, white, 0, 4))
        }
        card.addView(text("Datele sunt informative și nu constituie recomandări de investiții.", 9f, Typeface.DEFAULT, Color.rgb(125, 135, 155), 0, 8))
        host.content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, host.dp(9)) })
    }

    private fun addCompactWeights(parent: LinearLayout, weights: List<Int>) {
        if (weights.isEmpty()) return
        parent.addView(text("Ponderi", 10f, Typeface.DEFAULT_BOLD, white, 0, 5))
        val names = listOf("News", "BO", "Trend", "Mom", "Vol", "S/R", "Fund", "BB", "Ichimoku", "Mkt", "R/R", "ADX")
        val grid = LinearLayout(host.root.context).apply { orientation = LinearLayout.VERTICAL; setPadding(0, host.dp(2), 0, host.dp(1)) }
        val columns = 6
        for (r in 0 until 2) {
            val row = LinearLayout(host.root.context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            for (c in 0 until columns) {
                val i = r * columns + c
                val cell = LinearLayout(host.root.context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(host.dp(2), host.dp(2), host.dp(2), host.dp(2)) }
                cell.addView(text(names[i], 8f, Typeface.DEFAULT, muted, 0, 0), LinearLayout.LayoutParams(0, -2, 1f))
                cell.addView(text(weights.getOrNull(i)?.takeIf { it > 0 }?.toString() ?: "—", 9f, Typeface.DEFAULT_BOLD, cyan, 0, 0))
                row.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
            }
            grid.addView(row)
        }
        parent.addView(grid)
    }

    private fun addNews(items: List<OracleGrowthRecommendation>, fallbackNews: List<OracleNews>) {
        val recent = items.mapNotNull { item ->
            val n = fallbackNews.firstOrNull { it.ticker.equals(item.ticker, true) }
            if (n != null) n else if (item.newsTitle.isNotBlank()) OracleNews(item.ticker, item.newsTitle, item.newsSource, "", item.referenceTimestamp, false) else null
        }.distinctBy { it.ticker }
        if (recent.isEmpty()) return
        val card = card(12)
        card.addView(text("ȘTIRI & CATALIZATORI RECENȚI", 15f, Typeface.DEFAULT_BOLD, green, 0, 0))
        recent.forEach { n ->
            card.addView(text("▣  ${n.title}", 11f, Typeface.DEFAULT, white, 0, 7))
            card.addView(text("${formatT0(n.publishedAt)} • ${n.source}", 9f, Typeface.DEFAULT, muted, host.dp(18), 2))
        }
        host.content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, host.dp(8)) })
    }

    private fun addHistory(entries: List<OracleGrowthRecommendation>) {
        val card = card(12)
        val header = LinearLayout(host.root.context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(text("ULTIMELE RECOMANDĂRI", 15f, Typeface.DEFAULT_BOLD, cyan, 0, 0), LinearLayout.LayoutParams(0, -2, 1f))

        val download = TextView(host.root.context).apply {
            text = "⇩  PDF"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(8, 15, 28), cyan, 1, 10)
            setPadding(host.dp(13), host.dp(8), host.dp(13), host.dp(8))
            isClickable = true
            isFocusable = true
            contentDescription = "Descarcă jurnalul Growth în PDF"
            setOnClickListener {
                val path = journalStore.exportPdf()
                if (path != null) Toast.makeText(host.root.context, "Jurnalul Growth a fost salvat în Downloads.", Toast.LENGTH_LONG).show()
                else Toast.makeText(host.root.context, "Nu există recomandări pentru export.", Toast.LENGTH_SHORT).show()
            }
        }
        header.addView(download, LinearLayout.LayoutParams(host.dp(94), host.dp(40)))

        val arrow = TextView(host.root.context).apply {
            text = "⌄"
            textSize = 23f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(cyan)
            setPadding(0, 0, 0, host.dp(2))
            isClickable = true
            isFocusable = true
        }
        header.addView(arrow, LinearLayout.LayoutParams(host.dp(38), host.dp(40)))
        card.addView(header)

        val all = entries
            .filter { it.referenceTimestamp > 0L && it.referenceTimestamp >= startHistoryTimestamp() }
            .sortedWith(compareByDescending<OracleGrowthRecommendation> { it.referenceTimestamp }
                .thenBy { horizonOrder(it.horizon) }.thenBy { it.ticker })
        val rows = LinearLayout(host.root.context).apply { orientation = LinearLayout.VERTICAL }
        card.addView(rows)

        fun addPlaceholder() {
            val row = historyRow(null)
            rows.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, host.dp(6), 0, 0) })
        }
        fun addEntry(item: OracleGrowthRecommendation) {
            val row = historyRow(item)
            rows.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, host.dp(6), 0, 0) })
        }

        val visible = all.take(6)
        visible.forEach { addEntry(it) }
        repeat(maxOf(0, 6 - visible.size)) { addPlaceholder() }
        val expandedRows = all.drop(6)
        expandedRows.forEach {
            val row = historyRow(it)
            row.visibility = View.GONE
            rows.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, host.dp(6), 0, 0) })
        }
        var expanded = false
        arrow.setOnClickListener {
            expanded = !expanded
            arrow.text = if (expanded) "⌃" else "⌄"
            expandedRows.forEach { it.visibility = if (expanded) View.VISIBLE else View.GONE }
        }
        host.content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, host.dp(10)) })
    }

    private fun historyRow(item: OracleGrowthRecommendation?): LinearLayout {
        val accent = item?.let { when (it.horizon.uppercase(Locale.US)) { "SHORT" -> cyan; "MEDIUM" -> orange; else -> green } } ?: Color.rgb(60, 70, 90)
        return LinearLayout(host.root.context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(host.dp(10), host.dp(8), host.dp(10), host.dp(8))
            background = rounded(bg, accent, 1, 11)
            if (item == null) {
                addView(text("—", 18f, Typeface.DEFAULT_BOLD, muted, 0, 0))
                addView(text("—", 10f, Typeface.DEFAULT, muted, 0, 2))
            } else {
                val top = LinearLayout(host.root.context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                top.addView(text(item.ticker, 16f, Typeface.DEFAULT_BOLD, white, 0, 0), LinearLayout.LayoutParams(host.dp(72), -2))
                val identity = LinearLayout(host.root.context).apply { orientation = LinearLayout.VERTICAL }
                identity.addView(text(item.company.ifBlank { "—" }, 11f, Typeface.DEFAULT_BOLD, white, 0, 0))
                identity.addView(text(item.sector.ifBlank { "—" }, 9f, Typeface.DEFAULT_BOLD, Color.rgb(150, 170, 205), 0, 2))
                top.addView(identity, LinearLayout.LayoutParams(0, -2, 1f))
                top.addView(text(item.horizon, 9f, Typeface.DEFAULT_BOLD, accent, 0, 0))
                addView(top)
                val details = LinearLayout(host.root.context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, host.dp(5), 0, 0) }
                details.addView(text(formatT0(item.referenceTimestamp), 9f, Typeface.DEFAULT, muted, 0, 0), LinearLayout.LayoutParams(0, -2, 1f))
                details.addView(text("Forecast ${signedPct(item.forecastPct)}", 9f, Typeface.DEFAULT_BOLD, green, 0, 0), LinearLayout.LayoutParams(0, -2, 1f))
                details.addView(text("Scor ${item.score}/100", 9f, Typeface.DEFAULT_BOLD, cyan, 0, 0), LinearLayout.LayoutParams(0, -2, .8f))
                addView(details)
            }
        }
    }

    private fun startHistoryTimestamp(): Long {
        val f = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("ro", "RO"))
        f.timeZone = TimeZone.getTimeZone("Europe/Bucharest")
        return f.parse("31.08.2026 00:00")?.time ?: 0L
    }

    private fun horizonOrder(horizon: String) = when (horizon.uppercase(Locale.US)) { "SHORT" -> 0; "MEDIUM" -> 1; else -> 2 }
    private fun addBuildFooter() {
        host.content.addView(text("BUILD B535 • GROWTH", 9f, Typeface.DEFAULT_BOLD, Color.rgb(125, 135, 155), host.dp(4), 8), LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, host.dp(18)) })
    }

    private fun horizonLabel(horizon: String) = when (horizon.uppercase(Locale.US)) { "SHORT" -> "●  TERMEN SCURT"; "MEDIUM" -> "●  TERMEN MEDIU"; else -> "●  TERMEN LUNG" }
    private fun horizonRange(horizon: String) = when (horizon.uppercase(Locale.US)) { "SHORT" -> "1–10 zile bursiere"; "MEDIUM" -> "2–12 săptămâni"; else -> "3–12 luni" }
    private fun compactSignal(signal: String) = signal.replace("STRONG ", "STRONG\n").trim()
    private fun riskColor(risk: String): Int = if (risk.contains("RID", true)) red else orange
    private fun signedPct(v: Double) = if (v >= 0) "+${format(v)}%" else "${format(v)}%"
    private fun format(v: Double) = "%.1f".format(Locale.US, v)

    private fun formatT0(timestamp: Long): String {
        if (timestamp <= 0L) return "—"
        val f = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("ro", "RO")); f.timeZone = TimeZone.getTimeZone("Europe/Bucharest"); return f.format(Date(timestamp))
    }

    private fun card(padding: Int) = LinearLayout(host.root.context).apply { orientation = LinearLayout.VERTICAL; setPadding(host.dp(padding), host.dp(padding), host.dp(padding), host.dp(padding)); background = rounded(bg, border, 1, 16) }
    private fun rounded(fill: Int, stroke: Int, strokeWidth: Int, radius: Int) = GradientDrawable().apply { setColor(fill); if (strokeWidth > 0) setStroke(host.dp(strokeWidth), stroke); cornerRadius = host.dp(radius).toFloat() }
    private fun divider() = View(host.root.context).apply { setBackgroundColor(Color.rgb(35, 48, 70)); layoutParams = LinearLayout.LayoutParams(-1, host.dp(1)) }
    private fun metric(label: String, value: String, color: Int) = LinearLayout(host.root.context).apply { orientation = LinearLayout.VERTICAL; setPadding(host.dp(2), host.dp(2), host.dp(2), host.dp(2)); gravity = Gravity.CENTER; addView(text(label, 8f, Typeface.DEFAULT, muted, 0, 0).apply { gravity = Gravity.CENTER }); addView(text(value, 13f, Typeface.DEFAULT_BOLD, color, 0, 3).apply { gravity = Gravity.CENTER }) }
    private fun text(value: String, size: Float, typeface: Typeface, color: Int, left: Int, top: Int) = TextView(host.root.context).apply { text = value; textSize = size; this.typeface = typeface; setTextColor(color); setPadding(left, top, 0, 0) }

    private class SparklineView(context: android.content.Context, private val lineColor: Int) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas); paint.color = lineColor; val p = Path(); val pts = floatArrayOf(.02f,.78f, .14f,.55f, .25f,.67f, .37f,.44f, .48f,.57f, .61f,.31f, .73f,.46f, .86f,.20f, .98f,.05f)
            for (i in pts.indices step 2) { val x = pts[i] * width; val y = pts[i + 1] * height; if (i == 0) p.moveTo(x, y) else p.lineTo(x, y) }
            canvas.drawPath(p, paint); canvas.drawCircle(width * .98f, height * .05f, 4f, paint)
        }
    }
}
